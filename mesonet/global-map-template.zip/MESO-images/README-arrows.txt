README-arrows.txt   Updated: 28-Jun-2006

This set of transparent GIF arrows may be freely used, or replaced with your own.

The arrows are h=14, w=14 with transparent background.  In the SWN-mesomap.php script
they are used native size in the table display area, and resized by the browser to 10x10 
in the rotating conditions display area.

If you replace them, please ensure you have 16 GIFs , transparent background, sized at
14x14 pixels, and named with the upper-case wind direction:

	E.gif
	ENE.gif
	ESE.gif
	N.gif
	NE.gif
	NNE.gif
	NNW.gif
	NW.gif
	S.gif
	SE.gif
	SSE.gif
	SSW.gif
	SW.gif
	W.gif
	WNW.gif
	WSW.gif

Thanks to Kevin Reed at TNETWeather, we now have two new sets of arrows 
included in the distribution.
  *-sm.gif - are 9x9 arrows with transparent background 
  *.gif - are 14x14 arrows with transparent background (replaces original set)
  the backgrounds are anti-aliased with the background color of the SWN mesomap
  graphic.

Ken True
webmaster@saratoga-weather.org